# Showcase

## About
This will be a responsive webpage that I am going to use to showcase my project and act a blog to write down the things that I am going to do make this site better.

## Creator
Aishvarya Arul Nambi
